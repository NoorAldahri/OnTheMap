//
//  Global.swift
//  OnTheMap
//
//  Created by Noor Aldahri on 06/09/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

class Global {
    static let shared = Global()
    var studentsInformation: [StudentInformation]?
}
