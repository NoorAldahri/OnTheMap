//
//  NewPinViewController.swift
//  OnTheMap
//
//  Created by Noor Aldahri on 06/09/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import CoreLocation

class NewPinViewController: UIViewController {
    
    var locationCoordinate: CLLocationCoordinate2D!
    var locationName: String!
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var findOnTheMapButton: UIButton!
    
    @IBAction func findButton(_ sender: Any) {
        guard let locationName = textField.text?.trimmingCharacters(in: .whitespaces), !locationName.isEmpty
            else {
                alert(title: "Warning", message: "Location shouldn't be empty")
                return
        }
        getCoordinateFrom(location: locationName) { (locationCoordinate, error) in
            if let error = error {
                self.alert(title: "Error", message: "Try different city name")
                print(error.localizedDescription)
                return
            }
            self.locationCoordinate = locationCoordinate
            self.locationName = locationName
            self.performSegue(withIdentifier: "fromNewPinToShare", sender: self)
        }
    }
    
    func getCoordinateFrom(location: String, completion: @escaping(_ coordinate: CLLocationCoordinate2D?, _ error: Error?) -> () ) {
        CLGeocoder().geocodeAddressString(location) { plasemarks, error in
            completion(plasemarks?.first?.location?.coordinate, error)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        view.endEditing(true)
    }
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "fromNewPinToShare" {
            let vc = segue.destination as! ShareViewController
            vc.locationCoordinate = locationCoordinate
            vc.locationName = locationName
        }
    }
}


