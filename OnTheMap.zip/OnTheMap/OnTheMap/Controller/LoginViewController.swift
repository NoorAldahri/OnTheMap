//
//  LoginViewController.swift
//  OnTheMap
//
//  Created by Noor Aldahri on 06/09/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    @IBAction func login(_ sender: Any) {
        guard let email = emailField.text?.trimmingCharacters(in: .whitespaces),
            let password = passwordField.text?.trimmingCharacters(in: .whitespaces),
            !email.isEmpty, !password.isEmpty
            else {
                alert (title: "Warning", message: "Email and Password should not be Empty!")
                return
        }
        
        UdacityAPI.postSession(with: email, password: password) { (result, error) in
            if let error = error {
                self.alert(title: "Error", message: error.localizedDescription)
                return
            }
            if let error = result?["error"] as? String {
                self.alert(title: "Error", message: error)
                return
            }
            if let session = result?["session"] as? [String: Any], let sessionId = session["id"] as? String{
                UdacityAPI.deleteSession { (error) in
                    if let error = error {
                        self.alert(title: "Error", message: error.localizedDescription)
                        return
                    }
                    DispatchQueue.main.async {
                        self.emailField.text = ""
                        self.passwordField.text = ""
                        self.performSegue(withIdentifier: "showTabVC", sender: self)
                    }
                }
            }
        }
    }
    
    @IBAction func signUp(_ sender: Any) {
        
        let app = UIApplication.shared
        let url = URL(string: "https://auth.udacity.com/sign-up")
        app.open(url!, options: [:], completionHandler: nil)
    }
}

